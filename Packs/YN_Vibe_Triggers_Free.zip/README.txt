Thanks for downloading my triggers. 

Installation Process:
1. Select triggers you'd like to import.
2. Select the desired directory/profile, and click "Import Triggers"
3. Adjust vibes to your liking!

Just a few tips and suggestions.
1. Priority is prioritizes the highest triggers. If you're a healer, you'd set your heals as the highest number,damage abilities at a lower numbe. Same deal for DPS.
2. When editing skill/spells/abilities you want to put a "|" in-between them but no spaces (i.e. Benefic|Aspect Benefic|Benefic II)
3. Always have a STOP MOTOR trigger.


Please subscribe to FFXIV Vibe patreon!
https://www.patreon.com/kaciexx

Love, 
	YN Vibe Man